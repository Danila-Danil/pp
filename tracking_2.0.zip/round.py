f = open('tracker', 'r')

p1 = 0
p2 = 0
p3 = 0
p4 = 0
p5 = 0
p6 = 0
p7 = 0

mil = 0
csrt = 0
kcf = 0
tld = 0
boosting = 0
medianflow = 0
mosse = 0

for line in f:

    if(line == 'Используемый трекер: mil\n'):
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        mil = mil + c
        p1 = p1 + 1

    if (line == 'Используемый трекер: csrt\n'):
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        csrt = csrt + c
        p2 = p2 + 1

    if (line == 'Используемый трекер: kcf\n'):
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        kcf = kcf + c
        p3 = p3 + 1

    if (line == 'Используемый трекер: boosting\n'):
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        boosting = boosting + c
        p4 = p4 + 1

    if (line == 'Используемый трекер: tld\n'):
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        tld = tld + c
        p5 = p5 + 1

    if (line == 'Используемый трекер: medianflow\n'):
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        medianflow = medianflow + c
        p6 = p6 + 1

    if (line == 'Используемый трекер: mosse\n'):
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        mosse = mosse + c
        p7 = p7 + 1

mil = mil / p1
mil = round(mil, 2)
print(mil)

kcf = kcf / p3
kcf = round(kcf, 2)
print(kcf)

csrt = csrt / p2
csrt = round(csrt, 2)
print(csrt)

mosse = mosse / p7
mosse = round(mosse, 2)
print(mosse)

medianflow = medianflow / p6
medianflow = round(medianflow, 2)
print(medianflow)

tld = tld / p5
tld = round(tld, 2)
print(tld)

boosting = boosting / p4
boosting = round(boosting, 2)
print(boosting)


p = csrt

if (p < tld):
    p = tld

if (p < kcf):
    p = kcf

if (p < medianflow):
    p = medianflow

if (p < boosting):
    p = boosting

if (p < mosse):
    p = mosse

if (p < mil):
    p = mil

if (p == tld):
    print("Наиболььшее fps у трекера tld")
    print("Его значение:", p)

if (p == mil):
    print("Наиболььшее fps у трекера mil")
    print("Его значение:", p)

if (p == csrt):
    print("Наиболььшее fps у трекера csrt")
    print("Его значение:", p)

if (p == medianflow):
    print("Наиболььшее fps у трекера medianflow")
    print("Его значение:", p)

if (p == boosting):
    print("Наиболььшее fps у трекера boosting")
    print("Его значение:", p)

if (p == kcf):
    print("Наиболььшее fps у трекера kcf")
    print("Его значение:", p)

if (p == mosse):
    print("Наиболььшее fps у трекера mosse")
    print("Его значение:", p)










