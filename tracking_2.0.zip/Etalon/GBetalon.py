import csv

s = 0
u = 0
with open('v5.csv') as File:
    reader = csv.DictReader(File)
    for row in reader:
        x1 = int(row['x1'])
        y1 = int(row['y1'])
        h1 = int(row['h1'])
        w1 = int(row['w1'])
        x2 = int(row['x2'])
        y2 = int(row['y2'])
        h2 = int(row['h2'])
        w2 = int(row['w2'])

        t = 0

        x3 = x1 + w1
        x4 = x2 + w2
        y3 = y1 - h1
        y4 = y2 - h2

        # границы области пересечения
        left = max(x1, x2)  # левая
        bottom = max(y4, y3)  # нижняя
        right = min(x3, x4)  # правая
        top = min(y2, y1)  # верхняя

        width = right - left
        height = top - bottom


        if width <= 0 or height <= 0:
            t = 0
        else:

            t = (width * height) / (w1 * h1)

        u = u + 1
        s = s + t

s = s / u
s = round(s, 2)
s = s * 100
print(s, "%")


