import cv2
import argparse
from imutils.video import VideoStream
import time

ap = argparse.ArgumentParser()
ap.add_argument("-v", "--video", type=str,
                help="path to input video file")
args = vars(ap.parse_args())

if not args.get("video", False):
    print("[INFO] starting video stream...")
    vs = VideoStream(src=0).start()
    time.sleep(1.0)
else:
    vs = cv2.VideoCapture(args["video"])

f = open('../etalon koord/etalon_v4', 'r')


while True:

    g = 0
    while g == 0:
        k = f.readline()
        if (k == 'x=\n'):
            d = f.readline(5)
            x = float(d)
            round(x, 0)
            x = int(x)
            g = 1

    g = 0
    while g == 0:
        k = f.readline()
        if (k == 'y=\n'):
            d = f.readline(5)
            y = float(d)
            round(y, 0)
            y = int(y)
            g = 1

    g = 0
    while g == 0:
        k = f.readline()
        if (k == 'w=\n'):
            d = f.readline(5)
            w = float(d)
            round(w, 0)
            w = int(w)
            g = 1

    g = 0
    while g == 0:
        k = f.readline()
        if (k == 'h=\n'):
            d = f.readline(5)
            h = float(d)
            round(h, 0)
            h = int(h)
            g = 1
    frame = vs.read()
    frame = frame[1] if args.get("video", False) else frame

    if frame is None:
        break

    cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)


    cv2.imshow("Frame", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break


if not args.get("video", False):
    vs.stop()

else:
    vs.release()

cv2.destroyAllWindows()