f = open('../xy', 'r')
w = open('notfree', 'w')


w.write('X' + '\n' + '\n')
for line in f:
    if (f.read(2) == 'x='):
        k = f.readline()
        w.write(k)

f = open('../etalon koord/etalon_v4', 'r')
w.write('\n' + '\n' + 'Y'+ '\n'+ '\n')
for line in f:
    if (f.read(2) == 'y='):
        k = f.readline()
        w.write(k)

f = open('../etalon koord/etalon_v4', 'r')
w.write('\n' + '\n' + 'W'+ '\n'+ '\n')
for line in f:
    if (f.read(2) == 'w='):
        k = f.readline()
        w.write(k)

f = open('../etalon koord/etalon_v4', 'r')
w.write('\n' + '\n' + 'H'+ '\n'+ '\n')
for line in f:
    if (f.read(2) == 'h='):
        k = f.readline()
        w.write(k)



