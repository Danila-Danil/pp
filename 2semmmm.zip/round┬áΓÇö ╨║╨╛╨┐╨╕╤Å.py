f = open('vse', 'r')

p1 = 0
p2 = 0
p3 = 0
p4 = 0
p5 = 0
p6 = 0
p7 = 0

mil = 0
csrt = 0
kcf = 0
tld = 0
boosting = 0
medianflow = 0
mosse = 0

mil1 = 0
csrt1 = 0
kcf1 = 0
tld1 = 0
boosting1 = 0
medianflow1 = 0
mosse1 = 0

for line in f:

    if(line == 'Используемый трекер: mil\n'):
        f.readline()
        f.readline(32)
        d = f.readline(2)
        e = float(d)
        mil1 = mil1 + e
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        mil = mil + c
        p1 = p1 + 1

    if (line == 'Используемый трекер: csrt\n'):
        f.readline()
        f.readline(32)
        d = f.readline(2)
        e = float(d)
        csrt1 = csrt1 + e
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        csrt = csrt + c
        p2 = p2 + 1

    if (line == 'Используемый трекер: kcf\n'):
        f.readline()
        f.readline(32)
        d = f.readline(2)
        e = float(d)
        kcf1 = kcf1 + e
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        kcf = kcf + c
        p3 = p3 + 1

    if (line == 'Используемый трекер: boosting\n'):
        f.readline()
        f.readline(32)
        d = f.readline(2)
        e = float(d)
        boosting1 = boosting1 + e
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        boosting = boosting + c
        p4 = p4 + 1

    if (line == 'Используемый трекер: tld\n'):
        f.readline()
        f.readline(32)
        d = f.readline(2)
        e = float(d)
        tld1 = tld1 + e
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        tld = tld + c
        p5 = p5 + 1

    if (line == 'Используемый трекер: medianflow\n'):
        f.readline()
        f.readline(32)
        d = f.readline(2)
        e = float(d)
        medianflow1 = medianflow1 + e
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        medianflow = medianflow + c
        p6 = p6 + 1

    if (line == 'Используемый трекер: mosse\n'):
        f.readline()
        f.readline(32)
        d = f.readline(2)
        e = float(d)
        mosse1 = mosse1 + e
        f.readline()
        f.readline(22)
        b = f.readline(5)
        c = float(b)
        mosse = mosse + c
        p7 = p7 + 1

mil = mil / p1
mil1 = mil1 / p1
mil = round(mil, 2)
mil1 = round(mil1, 2)


kcf = kcf / p3
kcf1 = kcf1 / p3
kcf = round(kcf, 2)
kcf1 = round(kcf1, 2)

csrt = csrt / p2
csrt1 = csrt1 / p2
csrt = round(csrt, 2)
csrt1 = round(csrt1, 2)

mosse = mosse / p7
mosse1 = mosse1 / p7
mosse = round(mosse, 2)
mosse1 = round(mosse1, 2)

medianflow = medianflow / p6
medianflow1 = medianflow1 / p6
medianflow = round(medianflow, 2)
medianflow1 = round(medianflow1, 2)

tld = tld / p5
tld1 = tld1 / p5
tld = round(tld, 2)
tld1 = round(tld1, 2)

boosting = boosting / p4
boosting1 = boosting1 / p4
boosting = round(boosting, 2)
boosting1 = round(boosting1, 2)

p = csrt

if (p > tld):
    p = tld

if (p > kcf):
    p = kcf

if (p > medianflow):
    p = medianflow

if (p > boosting):
    p = boosting

if (p > mosse):
    p = mosse

if (p > mil):
    p = mil

if (p == tld):
    print("Наименьшее fps у трекера tld")
    print("Его значение:", p)

if (p == mil):
    print("Наименьшее fps у трекера mil")
    print("Его значение:", p)

if (p == csrt):
    print("Наименьшее fps у трекера csrt")
    print("Его значение:", p)

if (p == medianflow):
    print("Наименьшее fps у трекера medianflow")
    print("Его значение:", p)

if (p == boosting):
    print("Наименьшее fps у трекера boosting")
    print("Его значение:", p)

if (p == kcf):
    print("Наименьшее fps у трекера kcf")
    print("Его значение:", p)

if (p == mosse):
    print("Наименьшее fps у трекера mosse")
    print("Его значение:", p)

print("\n")

p11 = csrt1

if (p11 < tld1):
    p11 = tld1

if (p11 < kcf1):
    p11 = kcf1

if (p11 < medianflow1):
    p11 = medianflow1

if (p11 < boosting1):
    p11 = boosting1

if (p11 < mosse1):
    p11 = mosse1

if (p11 < mil1):
    p11 = mil1

if (p11 == tld1):
    print("Наибольший процент отслеживания у трекера tld")
    print("Его значение:", p11)

if (p11 == mil1):
    print("Наибольший процент отслеживания у трекера mil")
    print("Его значение:", p11)

if (p11 == csrt1):
    print("Наибольший процент отслеживания у трекера csrt")
    print("Его значение:", p11)

if (p11 == medianflow1):
    print("Наибольший процент отслеживания у трекера medianflow")
    print("Его значение:", p11)

if (p11 == boosting1):
    print("Наибольший процент отслеживания у трекера boosting")
    print("Его значение:", p11)

if (p11 == kcf1):
    print("Наибольший процент отслеживания у трекера kcf")
    print("Его значение:", p11)

if (p11 == mosse1):
    print("Наибольший процент отслеживания у трекера mosse")
    print("Его значение:", p11)





